/*
 * No copyright is claimed.  This code is in the public domain; do with
 * it what you wish.
 **/
#ifndef UTIL_LINUX_FILEUTILS
#define UTIL_LINUX_FILEUTILS

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

#ifdef HAVE_LINUX_OPENAT2_H
# include <linux/openat2.h>
#endif

#include "c.h"
#include "pathnames.h"

extern int mkstemp_cloexec(char *template);

extern int xmkstemp(char **tmpname, const char *dir, const char *prefix);

static inline FILE *xfmkstemp(char **tmpname, const char *dir, const char *prefix)
{
	int fd;
	FILE *ret;

	fd = xmkstemp(tmpname, dir, prefix);
	if (fd == -1)
		return NULL;

	if (!(ret = fdopen(fd, "w+" UL_CLOEXECSTR))) {
		close(fd);
		return NULL;
	}
	return ret;
}

#ifdef HAVE_OPENAT
static inline FILE *fopen_at(int dir, const char *filename,
                             int flags, const char *mode)
{
	int fd = openat(dir, filename, flags);
	FILE *ret;

	if (fd < 0)
		return NULL;

	ret = fdopen(fd, mode);
	if (!ret)
		close(fd);
	return ret;
}
#endif

static inline int is_same_inode(const int fd, const struct stat *st)
{
	struct stat f;

	if (fstat(fd, &f) < 0)
		return 0;
	else if (f.st_dev != st->st_dev || f.st_ino != st->st_ino)
		return 0;
	return 1;
}

extern int ul_open_no_symlinks(const char *path, int flags, mode_t mode);
extern int ul_openat_resolve(int dirfd, const char *path, int flags,
			     mode_t mode, unsigned long long resolve);

#ifndef RESOLVE_NO_SYMLINKS
# define RESOLVE_NO_SYMLINKS	0x04
#endif
#ifndef RESOLVE_BENEATH
# define RESOLVE_BENEATH	0x08
#endif

extern int dup_fd_cloexec(int oldfd, int lowfd);
extern unsigned int get_fd_tabsize(void);

extern int ul_mkdir_p(const char *path, mode_t mode);
extern char *stripoff_last_component(char *path);

/* This is readdir()-like function, but skips "." and ".." directory entries */
static inline struct dirent *xreaddir(DIR *dp)
{
	struct dirent *d;

	while ((d = readdir(dp))) {
		if (!strcmp(d->d_name, ".") ||
		    !strcmp(d->d_name, ".."))
			continue;
		break;
	}
	return d;
}


#ifdef HAVE_SYS_SYSCALL_H
# include <sys/syscall.h>

# if !defined(HAVE_CLOSE_RANGE) && defined(SYS_close_range)
#  include <sys/types.h>
static inline int close_range(unsigned int first, unsigned int last, int flags)
{
	return syscall(SYS_close_range, first, last, flags);
}
#  define HAVE_CLOSE_RANGE 1
# endif	/* SYS_close_range */

# if !defined(HAVE_STATX) && defined(HAVE_STRUCT_STATX) && defined(SYS_statx)
static inline int statx(int fd, const char *restrict path, int flags,
		    unsigned int mask, struct statx *stx)
{
	return syscall(SYS_statx, fd, path, flags, mask, stx);
}
#  define HAVE_STATX 1
# endif /* SYS_statx */

# if !defined(HAVE_FCHMODAT2) && defined(SYS_fchmodat2)
static inline int fchmodat2(int dirfd, const char *path, mode_t mode,
			    unsigned int flags)
{
	return syscall(SYS_fchmodat2, dirfd, path, mode, flags);
}
#  define HAVE_FCHMODAT2 1
# endif /* SYS_fchmodat2 */

# if !defined(HAVE_COPY_FILE_RANGE) && defined(SYS_copy_file_range)
static inline ssize_t copy_file_range(int fd_in, off_t *off_in,
			int fd_out, off_t *off_out, size_t size, unsigned int flags)
{
	return syscall(SYS_copy_file_range, fd_in, off_in, fd_out,
		off_out, size, flags);
}
# define HAVE_COPY_FILE_RANGE 1
# endif /* SYS_copy_file_range */

#endif	/* HAVE_SYS_SYSCALL_H */


extern void ul_close_all_fds(unsigned int first, unsigned int last);

#define UL_COPY_READ_ERROR (-1)
#define UL_COPY_WRITE_ERROR (-2)
int ul_copy_file(int from, int to);

/* Size of the buffer for ul_fd_mkpath() */
#define UL_FDPATH_BUFSIZ	(sizeof(_PATH_PROC_FDDIR) + sizeof(stringify_value(INT_MAX)))

extern int ul_reopen(int fd, int flags);
extern char *ul_fd_mkpath(char *buf, size_t bufsz, int fd);
extern char *ul_fd_get_path(int fd);
extern char *ul_basename(char *path);

extern char *ul_restricted_path_oper(const char *path,
		int (*oper)(const char *path, char **result, void *data),
		void *data);

/* return 1 if @d is "." or ".." */
static inline bool is_dotdir_dirent(const struct dirent *d)
{
	return (d && d->d_name[0] == '.'
		&& (d->d_name[1] == 0
		    || (d->d_name[1] == '.' && d->d_name[2] == 0)));
}

#endif /* UTIL_LINUX_FILEUTILS */
